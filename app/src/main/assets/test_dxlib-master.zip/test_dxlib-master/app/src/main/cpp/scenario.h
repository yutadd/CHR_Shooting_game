//
// Created by spyk4 on 2020/10/30.
//

#ifndef TEST_DXLIB_SCENARIO_H
#define TEST_DXLIB_SCENARIO_H


class scenario {

};


#endif //TEST_DXLIB_SCENARIO_H
